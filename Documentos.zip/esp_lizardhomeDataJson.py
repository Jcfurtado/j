# ------- JSON ------- #
# ESP8266 NodeMCU com MicroPython
# esp_lizardhomeDataJson.py
''' Requisitos
    1 - Coletar as informações dos Sensores DHT,    
    2 - Coletar estado das lâmpadas (ligado ou desligado),
    2 - Converter em Json (serialization/encoding),
    3 - Envia-las via MQTT ao servidor,
    4 - Receber Json com comandos de on/off,
        para as luzes (deserialization/decoding).
'''
import ujson


dhtJson = {
    "DHTSensor": [
        {
            "deviceSide": "HOT",
            "temp": 30,
            "humid": 20,
        },
        {
            "deviceSide": "COLD",
            "temp": 20,
            "humid": 40,
        }
    ],
}

lampJson = {
    "Lights": [
        {
            "light": "led_rgb",
            "state": "OFF",
        }
    ],
}


# ------- JSON encoding ------- #
with open("lizardhomeData_file.json", "w") as write_file:
    ujson.dump(dhtJson, write_file)


with open("lizardhomeLights_file.json", "w") as write_file:
    ujson.dump(lampJson, write_file)


# ------- JSON decoding ------- #
with open("lizardhomeData_file.json", "r") as read_file:
    dhtData = ujson.load(read_file)


with open("lizardhomeLights_file.json", "r") as read_file:
    lightData = ujson.load(read_file)


print('DHT: {}\nLuzes: {}'.format(dhtData, lightData))
