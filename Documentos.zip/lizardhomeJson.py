# ------- JSON ------- #
# 
dhtJson = {
    "DHTSensor": [
        {
            "deviceSide": "HOT",
            "temp": 25,
            "humid": 35,
        }
    ],
}

lampJson = {
    "Lights": [
        {
            "light": "led_rgb",
            "state": "OFF",
        }
    ],
}


# ------- JSON encoding ------- #
with open("lizardhomeData_file.json", "w") as write_file:
    ujson.dump(dhtJson, write_file)


with open("lizardhomeLights_file.json", "w") as write_file:
    ujson.dump(lampJson, write_file)


# ------- JSON decoding ------- #
with open("lizardhomeData_file.json", "r") as read_file:
    dhtData = ujson.load(read_file)


with open("lizardhomeLights_file.json", "r") as read_file:
    lightData = ujson.load(read_file)


print('DHT: {}\nLuzes: {}'.format(dhtData, lightData))