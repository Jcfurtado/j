import requests
# from time import sleep
from time import localtime


# base_url variable to store url
base_url = "https://api.sunrise-sunset.org/json?"
# Latitude e Longitude in decimal degrees
lat = "lat=-23.6573395"
lng = "lng=-46.5322504"
date = "date=today"
# complete_url variable to store
# complete url address
complete_url = base_url + lat + "&" + lng + "&" + date


def sun_api(complete_url):
    r = requests.get(complete_url)
    data = r.json()
    if data["status"] == "OK":
        idx_sys = data["results"]
        twilight_begin = idx_sys["civil_twilight_begin"]
        current_sunrise = idx_sys["sunrise"]
        current_sunset = idx_sys["sunset"]
        twilight_end = idx_sys["civil_twilight_end"]
    else:
        print('City Not Found')
    return twilight_begin, current_sunrise, current_sunset, twilight_end


def to_utc(xpt):
    o = str(xpt)
    x = o.split(':')
    p = x[0:2]
    v = int(p[0])

    utc = 3
    cv = (v - utc)

    q = str(cv)
    u = str(p[1])
    s = [q, u]
    t = tuple(s)
    return t


def to_twentyfour(xpt):
    o = str(xpt)
    x = o.split(':')
    p = x[0:2]
    v = int(p[0])

    tf = 12
    cv = (v + tf)

    q = str(cv)
    u = str(p[1])
    s = [q, u]
    t = tuple(s)
    return t


def to_xpt(xpt):
    o = str(xpt)
    x = o.split(':')
    p = x[0:2]
    v = int(p[0])

    utc = 3
    tf = 12
    cv = (v - utc) + tf

    q = str(cv)
    u = str(p[1])
    s = [q, u]
    t = tuple(s)
    return t


begin = 6
sunrise = 7
sunset = 18
end = 19
night = 23
moon = 00

lt = localtime()
now = lt[3]

print('\nFOR ... ')
while True:
    if now >= moon and now < begin:
        print('func NOITE - ON!')
    elif now >= begin and now < sunrise:
        print('func NOITE - OFF!')
        print('sunrise - ON!')
    elif now >= sunrise and now < sunset:
        print('sunrise - OFF!')
        print('func DAY - ON!')
    elif now >= sunset and now < end:
        print('func DAY - OFF!')
        print('sunset - ON!')
    elif now >= end and now <= night:
        print('sunset - OFF!')
        print('func NOITE - ON!')
    else:
        print('error... controller')
        break


""" if now_h >= '0' or now_h <= '23' and now_m >= '0' or now_m <= '59':
    print('sim')
else:
    print('nao') """
