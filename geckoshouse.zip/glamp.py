"""
NodeMCU ESP8266 - GPIO
(D1 = 5) RGB LED overnight (Temp >= 22°C)
(D2 = 4) DHT22 sensor
(D5 = 14) UV light (7 as 10hs)
(D6 = 12) UVA-B light (12 as 14hs)
(D7 = 13) day heat lamp (Temp < 22°C)
(D8 = 15) night heat lamp (Temp < 22°C)
"""
from machine import Pin
from utime import localtime

from geckoshouse import gdht
from geckoshouse import gled

lpd_uv = Pin(14, Pin.OUT, Pin.PULL_UP)  # (D5) UV light
lpd_uva = Pin(12, Pin.OUT, Pin.PULL_UP)  # (D6) UVA-B light
lpd_day = Pin(13, Pin.OUT, Pin.PULL_UP)  # (D7) day heat lamp
lpd_night = Pin(15, Pin.OUT, Pin.PULL_UP)  # (D8) night heat lamp


def day_time():  # controller day lamps
    uv_on = 7
    uv_off = 10
    uva_on = 12
    uva_off = 14
    while True:
        lt = localtime()
        rooster = lt[3]
        # dht / temp min
        temp = gdht.dht_temperature()
        temp_min = 22
        # controller
        if temp < temp_min:  # day heat lamp
            lpd_day.on()
            print("\n day heat lamp, on!")
        elif temp > temp_min:
            lpd_day.off()
            print("\n day heat lamp, off!")
        elif uv_on == rooster:  # UV light
            lpd_uv.on()
            print("\n UV light, on!")
        elif uv_off == rooster:
            lpd_uv.off()
            print("\n UV light, off!")
        elif uva_on == rooster:  # UVA-B light
            lpd_uva.on()
            print("\n UVA-B light, on!")
        elif uva_off == rooster:
            lpd_uva.off()
            print("\n UVA-B light, off!")
        else:
            print('error... day_time')


def night_time():  # controller overnight lamps
    while True:
        # dht / temp min
        temp = gdht.dht_temperature()
        temp_min = 22
        # controller
        if temp < temp_min:  # night heat lamp
            lpd_night.on()
            print("\n night heat lamp, on!")
        elif temp > temp_min:
            lpd_night.off()
            print("\n night heat lamp, off!")
        if temp >= temp_min:  # overnight LED
            gled.overnight()
            print("\n LED overnight, on!")
        else:
            gled.clear()
            print("\n LED overnight, off!")
