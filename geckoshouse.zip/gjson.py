import json


def w_dht(area, temp, humid):
    dht_json = {
        "dht":
            {
                "area": area,
                "temperature": temp,
                "humidity": humid
            },

    }
    with open("gdht.json", "w") as write_file:
        json.dump(dht_json, write_file)


def r_dht():
    with open("gdht.json", "r") as read_file:
        measurement = json.load(read_file)
    return measurement


def w_lamp(uv, uva, rgb, day, night):
    lamp_json = {
        "lamps": {
            "uv": uv,
            "uva": uva,
            "led": rgb,
            "h_day": day,
            "h_night": night
        }
    }
    with open("glamp.json", "w") as write_file:
        json.dump(lamp_json, write_file)


def r_lamp():
    with open("glamp.json", "r") as read_file:
        lamps = json.load(read_file)
    return lamps
