"""
Sunset and sunrise times API
https://sunrise-sunset.org/api
"""
from urequests import urequests


def url_api():
    # base_url variable to store url
    base_url = "https://api.sunrise-sunset.org/json?"
    # Latitude e Longitude in decimal degrees
    lat = "lat=-23.6573395"
    lng = "lng=-46.5322504"
    date = "date=today"
    # complete_url variable to store
    # complete url address
    complete_url = base_url + lat + "&" + lng + "&" + date
    return complete_url


def sunrise_api():
    url = url_api()
    r = urequests.get(url)
    data = r.json()
    if data["status"] == "OK":
        idx_sys = data["results"]
        current_sunrise = idx_sys["sunrise"]
    else:
        print('City Not Found')
    return current_sunrise


def sunset_api():
    url = url_api()
    r = urequests.get(url)
    data = r.json()
    if data["status"] == "OK":
        idx_sys = data["results"]
        current_sunset = idx_sys["sunset"]
    else:
        print('City Not Found')
    return current_sunset


def twilight_begin():
    url = url_api()
    r = urequests.get(url)
    data = r.json()
    if data["status"] == "OK":
        idx_sys = data["results"]
        twilight_begin = idx_sys["civil_twilight_begin"]
    else:
        print('City Not Found')
    return twilight_begin


def twilight_end():
    url = url_api()
    r = urequests.get(url)
    data = r.json()
    if data["status"] == "OK":
        idx_sys = data["results"]
        twilight_end = idx_sys["civil_twilight_end"]
    else:
        print('City Not Found')
    return twilight_end


def sun_api():
    url = url_api()
    r = urequests.get(url)
    data = r.json()
    if data["status"] == "OK":
        idx_sys = data["results"]
        twilight_begin = idx_sys["civil_twilight_begin"]
        current_sunrise = idx_sys["sunrise"]
        current_sunset = idx_sys["sunset"]
        twilight_end = idx_sys["civil_twilight_end"]
    else:
        print('City Not Found')
    return twilight_begin, current_sunrise, current_sunset, twilight_end


def to_utc(xpt):
    o = str(xpt)
    x = o.split(':')
    p = x[0:2]
    v = int(p[0])

    utc = 3
    cv = (v - utc)

    q = str(cv)
    u = str(p[1])
    s = [q, u]
    t = tuple(s)
    return t


def to_twenty_four(xpt):
    o = str(xpt)
    x = o.split(':')
    p = x[0:2]
    v = int(p[0])

    tf = 12
    cv = (v + tf)

    q = str(cv)
    u = str(p[1])
    s = [q, u]
    t = tuple(s)
    return t


def to_xpt(xpt):
    o = str(xpt)
    x = o.split(':')
    p = x[0:2]
    v = int(p[0])

    utc = 3
    tf = 12
    cv = (v - utc) + tf

    q = str(cv)
    u = str(p[1])
    s = [q, u]
    t = tuple(s)
    return t
