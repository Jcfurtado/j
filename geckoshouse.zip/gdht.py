"""
NodeMCU ESP8266 - GPIO
(D1 = 5) RGB LED overnight (Temp >= 22°C)
(D2 = 4) DHT22 sensor
(D5 = 14) UV light (7 as 10hs)
(D6 = 12) UVA-B light (12 as 14hs)
(D7 = 13) day heat lamp (Temp < 22°C)
(D8 = 15) night heat lamp (Temp < 22°C)
"""
from time import sleep

from machine import Pin

from .dht import dht


def dht_sensor():  # ( Sensor DHT hot side)
    sensor = dht.DHT22(Pin(4, Pin.IN, Pin.PULL_UP))
    sensor.measure()
    temp = sensor.temperature()  # eg. 30.6 (°C)
    humid = sensor.humidity()  # eg. 25.3 (% RH)

    return temp, humid


def dht_temperature():
    temperature = dht_sensor()[0]
    return temperature


def dht_humidity():
    while True:
        humidity = dht_sensor()[1]
        sleep(4)
        return humidity
