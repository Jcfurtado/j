"""
NodeMCU ESP8266 - GPIO
(D1 = 5) RGB LED overnight (Temp >= 22°C)
(D2 = 4) DHT22 sensor
(D5 = 14) UV light (7 as 10hs)
(D6 = 12) UVA-B light (12 as 14hs)
(D7 = 13) day heat lamp (Temp < 22°C)
(D8 = 15) night heat lamp (Temp < 22°C)
"""
from machine import Pin
from neopixel import NeoPixel

nol = 12  # the number 12 is number of led
led = NeoPixel(Pin(5), nol)


def clear():
    for i in range(nol):
        led[i] = (0, 0, 0)
        led.write()


def twilight():
    sunset = 128, 88, 0
    for i in range(4 * nol):
        for j in range(nol):
            led[j] = sunset
        led.write()


def overnight():
    night = 15, 0, 45
    for i in range(4 * nol):
        for j in range(nol):
            led[j] = night
        led.write()
