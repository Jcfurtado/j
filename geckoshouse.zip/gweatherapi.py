from urequests import urequests


def api_url():
    # Enter with you API key
    api_key = "04e1541a44923bd07c915b83d6735b48"
    # base_url variable to store url
    base_url = "http://api.openweathermap.org/data/2.5/weather?"
    # ID of city
    city_id = 3449701
    # For Fahrenheit use imperial,
    # for Celsius use metric,
    # and the default is Kelvin.
    unit = "metric"
    # complete_url variable to store
    # complete url address
    complete_url = base_url + "id=" + str(city_id) + "&mode=json&units=" + unit + "&appid=" + api_key
    return complete_url


def api_weather():
    url = api_url()
    r = urequests.get(url)
    data = r.json()
    if data["cod"] != "404":
        idx_name = data["name"]
        idx_main = data["main"]
        current_temperature = idx_main["temp"]
        current_humidity = idx_main["humidity"]
    return idx_name, current_temperature, current_humidity
