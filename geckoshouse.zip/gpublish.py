from time import sleep

from umqtt.simple import MQTTClient

from .gdht import sensor_dht


def data_pub(server="192.168.1.6"):
    c = MQTTClient("esp8266", server)
    c.connect()
    # hot side
    temp, humid = sensor_dht()
    # Measurements
    all_measurements = [temp, humid]
    while True:
        for measurement in all_measurements:
            c.publish(b"tempone", "Temp: {}°C\nHumid: {}%\n".format(*all_measurements).encode("utf-8"))
            sleep(2)
        c.disconnect()
