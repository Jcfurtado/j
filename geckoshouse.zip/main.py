import machine
import network
import utime
from ntptime import settime

from geckoshouse import gcontroller


def post_boot():
    lan = network.WLAN(network.STA_IF)
    lan.active(True)
    if not lan.isconnected():
        print('connecting to network...')
        lan.connect("CL24H", "1234509876")
        while not lan.isconnected():
            pass
    print('network config:', lan.ifconfig())
    print('connected is ', lan.isconnected())

    led = machine.Pin(2, machine.Pin.OUT)

    settime()
    rtc = machine.RTC()
    utc_shift = 3
    tm = utime.localtime(utime.mktime(utime.localtime()) - utc_shift * 3600)
    tm = tm[0:3] + (0,) + tm[3:6] + (0,)
    rtc.datetime(tm)


if __name__ == '__main__':
    post_boot()
    gcontroller.ctrl_routine()
