"""
moon = 00 is a alternative to simulate the midnight hour
begin = 6 is a alternative to simulate the twilight begin before sunrise
sunrise = 7 is a alternative to simulate the sunrise
sunset = 18 is a alternative to simulate the sunset, the begin of twilight
end = 19 is a alternative to simulate the end of twilight
night = is a alternative to simulate the night before the midnight
"""
from utime import localtime

from geckoshouse import glamp, gled


def ctrl_routine():
    lt = localtime()
    now = lt[3]

    begin = 6
    sunrise = 7
    sunset = 18
    end = 19
    night = 23
    moon = 00

    while True:
        if now >= moon and now < begin:
            glamp.night_time()
            print('night_time [ON]')
        elif now >= begin and now < sunrise:
            gled.twilight()
            print('night_time [OFF] - twilight [ON]')
        elif now >= sunrise and now < sunset:
            glamp.day_time()
            gled.clear()
            print('sunrise [OFF] - day_time [ON]')
        elif now >= sunset and now < end:
            gled.twilight()
            print('day_time [OFF] - twilight [ON]')
        elif now >= end and now <= night:
            glamp.night_time()
            gled.clear()
            print('twilight [OFF] - night_time [ON]')
        else:
            print('error... controller')
            break
